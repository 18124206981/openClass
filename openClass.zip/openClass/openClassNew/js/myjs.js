/*初始动画*/
new WOW().init();

/*隐藏显示*/
$("#registerSubmit").click(function(){
    $(".before").hide();
    $(".after").show();
});

/* 幻灯片*/
var swiper2 = new Swiper('.slider-swiper .swiper-container', {
    prevButton: '.swiper-button-prev',
    nextButton: '.swiper-button-next',
    paginationClickable: true,
    pagination : '.swiper-pagination',
    slidesPerView: 2,
    spaceBetween: 50,
    breakpoints: {
        1024: {
            slidesPerView: 2,
            spaceBetween: 40
        },
        830: {
            slidesPerView: 2,
            spaceBetween: 30
        },
        465: {
            slidesPerView: 1,
            spaceBetween: 20
        },
        414: {
            slidesPerView: 1,
            spaceBetween: 10
        }
    }
});

/*拷贝输入框内容*/
function GetQueryString(name) {
    var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)");
    var r = window.location.search.substr(1).match(reg);
    if (r != null) return unescape(r[2]); return null;
}
$("#CopyInput").val(GetQueryString("code"));

var clipboard = new Clipboard('#clip_button', {
    text: function () {
        return $("#CopyInput").val();
    }
});

clipboard.on('success', function (e) {
    alert("复制成功");
});

clipboard.on('error', function (e) {
    alert("复制失败，请手动复制！");
});


